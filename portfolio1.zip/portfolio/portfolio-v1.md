```mermaid
sequenceDiagram
    participant Alice 
    participant Bob
    Alice->Bob: Hi Bob
    Bob->>Alice: Hi Alice