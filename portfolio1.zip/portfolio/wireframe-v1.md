```mermaid
graph TD
    A[Prosjektoversikt] --> B[Liste over Prosjekter]
    A --> C[Skjema for å opprette nytt prosjekt]
    
    B --> D[Prosjekt 1]
    B --> E[Prosjekt 2]
    B --> F[Prosjekt 3]
    
    C --> G[Prosjektnavn]
    C --> H[Beskrivelse]
    C --> I[Startdato]
    C --> J[Sluttdato]
    C --> K[Lagre]